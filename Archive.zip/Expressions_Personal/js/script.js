// Eddie Rosa
//Expressions Personal
//May 11, 2014

alert("We will be calculating how much it will cost you to completely fill your gas tank from empty")

var amountGas = prompt("Please enter the amount of gas your car can hold:");
var perGallon = prompt("Please enter the price of gas per gallon:");

var actualCost = perGallon * amountGas;

prompt("The amount that you are paying for gas is $" + actualCost + " for " + amountGas + " gallons of gas that your car can hold." );



